from setuptools import setup

setup(
    name='Weather',
    version='1.0.0',
    description='Get Weather Of Your City',
    author='LeaderOfTheWolves',
    author_email='ImLeaderOfTheWolves@gmail.com',
    packages=['weather'],
    classifiers = [
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "License :: OSI Approved :: MIT License",
    ]
)